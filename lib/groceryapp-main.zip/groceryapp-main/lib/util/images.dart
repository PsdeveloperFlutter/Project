class GetImages{
  static String onboardingImage = "onboarding_image.png";
  static String userImage = "user_image.png";
  static String mangoImage = "mango.png";
  static String painappleImage = "painapple.png";
  static String watermellonImage = "watermellon.png";
  static String starowberryImage = "starowberry.png";
  static String orangeImage = "orange.png";
  static String grapeImage = "grape.png";
  static String appleImage = "apple.png";
  static String pomegranatesImage = "pomegranates.png";
}