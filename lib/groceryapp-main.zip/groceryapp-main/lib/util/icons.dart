class GetIcons{
  static String addIcon = "add_icon.svg";
  static String backArrowIcon = "back_arrow.svg";
  static String homerIconselected = "home_icon_selected.svg";
  static String homerIconUnselected = "home_icon_unselected.svg";
  static String smsIcon = "sms_icon.svg";
  static String mailIcon = "mail_icon.svg";
  static String userIcon = "user_icon.svg";
}