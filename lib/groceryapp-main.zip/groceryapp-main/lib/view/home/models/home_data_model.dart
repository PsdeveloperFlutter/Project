import 'dart:ui';

class CategoryData{
  String? image;
  String? title;
  String? itemCount;
  Color? catBgColor;
  CategoryData(this.image,this.title,this.itemCount,this.catBgColor);
}