class Fruit{
  String? image;
  String? weight;
  String? name;
  String? price;
  Fruit(this.image,this.weight,this.price,this.name);
}